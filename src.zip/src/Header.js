import React, { useState } from "react";
import { Link } from "react-router-dom"; // Import Link for navigation
import "./Header.css";
import headerImage from "./header.png"; // Adjust the path as needed

const categories = [
  {
    id: 1,
    name: "Financial Services",
    subcategories: [
      { id: "a", name: "Retail Banking", link: "/financial-services" },
      {
        id: "b",
        name: "Assets & Wealth Management",
        link: "/financial-services",
      },
      { id: "c", name: "Insurance", link: "/financial-services" },
      { id: "d", name: "Mortgages & Loan", link: "/financial-services" },
    ],
  },
  {
    id: 2,
    name: "Account Services",
    subcategories: [
      { id: "e", name: "Oil & Gas", link: "/financial-services" },
      {
        id: "f",
        name: "Discrete Manufacturing",
        link: "/financial-services",
      },
      { id: "g", name: "Automobile", link: "/financial-services" },
      { id: "h", name: "Logistics", link: "/financial-services" },
    ],
  },
  {
    id: 3,
    name: "Health & Life Sciences",
    subcategories: [
      {
        id: "i",
        name: "Sub Category 1",
        link: "/financial-services",
      },
      {
        id: "j",
        name: "Sub Category 2",
        link: "/financial-services",
      },
      {
        id: "k",
        name: "Sub Category 3",
        link: "/financial-services",
      },
      {
        id: "l",
        name: "Sub Category 4",
        link: "/financial-services",
      },
    ],
  },
  {
    id: 4,
    name: "Account Services",
    subcategories: [
      {
        id: "m",
        name: "Sub Category 1",
        link: "/account-services/subcategory1",
      },
      {
        id: "n",
        name: "Sub Category 2",
        link: "/account-services/subcategory2",
      },
      {
        id: "o",
        name: "Sub Category 3",
        link: "/account-services/subcategory3",
      },
      {
        id: "p",
        name: "Sub Category 4",
        link: "/account-services/subcategory4",
      },
    ],
  },
  {
    id: 5,
    name: "Health & Lifesciences",
    subcategories: [
      {
        id: "q",
        name: "Sub Category 1",
        link: "/health-lifesciences/subcategory1",
      },
      {
        id: "r",
        name: "Sub Category 2",
        link: "/health-lifesciences/subcategory2",
      },
      {
        id: "s",
        name: "Sub Category 3",
        link: "/health-lifesciences/subcategory3",
      },
      {
        id: "t",
        name: "Sub Category 4",
        link: "/health-lifesciences/subcategory4",
      },
    ],
  },
  // Add more categories here
];

const Header = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <header className="header">
      <div className="hamburger-menu" onClick={toggleSidebar}>
        <span className="hamburger-icon">☰</span>
      </div>
      <div className="header-image">
        <img src={headerImage} alt="Header" />
      </div>
      {isSidebarOpen && (
        <div className="sidebar">
          <button className="close-btn" onClick={toggleSidebar}>
            ×
          </button>
          <div className="sidebar-content">
            {categories.map((category) => (
              <div key={category.id} className="category-box">
                <strong>{category.name}</strong>
                <ul className="subcategory-list">
                  {category.subcategories.map((subcategory) => (
                    <li key={subcategory.id} className="subcategory-item">
                      <Link to={subcategory.link}>{subcategory.name}</Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
