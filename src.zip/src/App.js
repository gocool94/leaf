import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Sidebar from "./Sidebar";
import TopicsList from "./TopicsList";
import RetailBankingDetail from "./RetailBankingDetail"; // Example of a detailed view
import "./App.css";
import Header from "./Header";
import SearchResults from "./SearchResults"; // Your existing CSS file

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <Router>
      <div className="app">
        <Header />
        <div className="app-container">
          {isSidebarOpen && <Sidebar />}
          <div className="main-content">
            <Routes>
              <Route path="/" element={<TopicsList />} />
              <Route path="/search" element={<SearchResults />} />
              <Route
                path="/financial-services"
                element={<RetailBankingDetail />}
              />
            </Routes>
          </div>
        </div>
      </div>
    </Router>
  );
}

export default App;
