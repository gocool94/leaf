import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./TopicsList.css";

const topics = [
  { id: 1, name: "Automobiles", icon: "🏦", path: "/financial-services" },
  { id: 2, name: "Manufacturing", icon: "🏭", path: "/financial-services" },
  {
    id: 3,
    name: "Healthcare & Life Science",
    icon: "🧑‍⚕️",
    path: "/financial-services",
  },
  { id: 4, name: "Technology", icon: "💻", path: "/financial-services" },
  {
    id: 5,
    name: "Media & Entertainment",
    icon: "🎬",
    path: "/financial-services",
  },
  { id: 6, name: "Retail & CPG", icon: "🛒", path: "/financial-services" },
  {
    id: 7,
    name: "Professional Services & Consulting",
    icon: "💼",
    path: "/financial-services",
  },
];

const TopicsList = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  const handleSearch = (event) => {
    if (event.key === "Enter") {
      navigate(`/search?query=${searchQuery}`);
    }
  };

  return (
    <div className="topics-container">
      <div className="inner-box">
        <div className="search-bar">
          <input
            type="text"
            placeholder="Search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={handleSearch} // Handle Enter key to trigger search
          />
        </div>
        <div className="common-topics">
          <span>Common Topics: </span>
          <a href="#">Oil & Gas</a>, <a href="#">Retail Banking</a>,{" "}
          <a href="#">Insurance</a>
        </div>
        <ul className="topics-list">
          {topics.map((topic) => (
            <li key={topic.id} className="topic-item">
              <Link to={topic.path} className="topic-link">
                <span className="topic-icon">{topic.icon}</span>
                <span className="topic-name">{topic.name}</span>
                <span className="topic-arrow">➡️</span>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default TopicsList;
