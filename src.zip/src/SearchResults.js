import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import data from "./kpi_output.json"; // Update this path to your JSON file

const SearchResults = () => {
  const [filteredResults, setFilteredResults] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [resultsPerPage] = useState(10); // Set to 10 results per page
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const searchQuery = queryParams.get("query");
  const navigate = useNavigate(); // React Router hook for navigation

  useEffect(() => {
    if (searchQuery) {
      const results = [];

      // Search logic: Check if the search query matches any title, industry, department, or KPI
      data.forEach((domain) => {
        domain.industries.forEach((industry) => {
          industry.classifications.forEach((classification) => {
            classification.departments.forEach((department) => {
              department.subdepartments.forEach((subdepartment) => {
                subdepartment.kpicollection.forEach((kpi) => {
                  const combinedTitle = `${subdepartment.subdepartment}: ${kpi.kpi}`;
                  if (
                    combinedTitle
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase()) ||
                    industry.industry
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase()) ||
                    department.department
                      .toLowerCase()
                      .includes(searchQuery.toLowerCase()) ||
                    kpi.kpi.toLowerCase().includes(searchQuery.toLowerCase())
                  ) {
                    results.push({
                      id: `${subdepartment.subdepartment}_${kpi.kpi}`, // Unique ID for each result
                      title: combinedTitle,
                      industry: industry.industry,
                      department: department.department,
                      formula: kpi.formula, // Add the formula field
                      explanation: kpi.explanation, // Add the explanation field
                    });
                  }
                });
              });
            });
          });
        });
      });

      setFilteredResults(results);
    }
  }, [searchQuery]);

  // Pagination logic
  const indexOfLastResult = currentPage * resultsPerPage;
  const indexOfFirstResult = indexOfLastResult - resultsPerPage;
  const currentResults = filteredResults.slice(
    indexOfFirstResult,
    indexOfLastResult
  );

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  // Function to navigate back to the home page
  const goBackHome = () => {
    navigate("/"); // This will take you back to the home route
  };

  return (
    <div className="search-results-page py-6 px-8 bg-gray-100 min-h-screen">
      {/* Back to Home Button */}
      <div className="mb-6">
        <button
          onClick={goBackHome}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          Back to Home
        </button>
      </div>

      <h2 className="text-2xl font-semibold text-gray-800 mb-6">
        Search Results
      </h2>
      <div className="text-lg text-gray-600 mb-4">
        Results for "{searchQuery}":
      </div>

      <div className="results-container grid grid-cols-1 gap-6">
        {currentResults.length > 0 ? (
          currentResults.map((result) => (
            <div
              key={result.id}
              className="bg-white shadow-sm rounded-md p-5 hover:shadow-lg transition duration-300 ease-in-out"
            >
              <h3 className="text-xl font-medium text-gray-800 mb-3">
                {result.title}
              </h3>
              <div className="result-tags mb-3 flex space-x-2">
                <button className="px-3 py-1 bg-blue-100 text-blue-700 text-sm rounded-full hover:bg-blue-200">
                  {result.industry}
                </button>
                <button className="px-3 py-1 bg-green-100 text-green-700 text-sm rounded-full hover:bg-green-200">
                  {result.department}
                </button>
              </div>

              {/* Display KPI, formula, and explanation */}
              <div className="result-details">
                <p className="text-sm font-semibold text-gray-700">
                  <strong>KPI:</strong> {result.title}
                </p>
                <p className="text-sm text-gray-700">
                  <strong>Formula:</strong>{" "}
                  {result.formula ? result.formula : "N/A"}
                </p>
                <p className="text-sm text-gray-700">
                  <strong>Explanation:</strong>{" "}
                  {result.explanation ? result.explanation : "N/A"}
                </p>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-gray-600">
            No results found for "{searchQuery}".
          </p>
        )}
      </div>

      {/* Pagination */}
      {filteredResults.length > resultsPerPage && (
        <div className="pagination flex justify-center mt-6 space-x-2">
          {Array.from(
            { length: Math.ceil(filteredResults.length / resultsPerPage) },
            (_, i) => (
              <button
                key={i + 1}
                onClick={() => paginate(i + 1)}
                className={`px-3 py-1 border rounded-md text-sm ${
                  currentPage === i + 1
                    ? "bg-blue-600 text-white"
                    : "bg-gray-200 text-gray-700 hover:bg-blue-500 hover:text-white"
                }`}
              >
                {i + 1}
              </button>
            )
          )}
        </div>
      )}
    </div>
  );
};

export default SearchResults;
