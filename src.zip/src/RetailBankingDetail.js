import React, { useState } from "react";
import { Link } from "react-router-dom";
import Modal from "./Modal";
import "./RetailBankingDetail.css";
import html2pdf from "html2pdf.js";
import kpiData from "./kpi_output.json"; // Import the JSON file

const RetailBankingDetail = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState(null);

  // Extract data from JSON file
  const sections = kpiData
    .map((domainData) =>
      domainData.industries.map((industryData) =>
        industryData.classifications.map((classification) => {
          return {
            name: classification.classification, // Classification as Section
            categories: classification.departments.map((department) => {
              return {
                name: department.department, // Department as Category
                topics: department.subdepartments.map((subdepartment) => ({
                  name: subdepartment.subdepartment, // Subdepartments as Topics
                  kpis: subdepartment.kpicollection, // Associated KPIs
                })),
              };
            }),
          };
        })
      )
    )
    .flat(2); // Flatten the array twice since we map over nested arrays

  const handleTopicClick = (section, category, topic) => {
    setModalContent({ section, category, topic });
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  const handleExportPDF = () => {
    const element = document.body; // Or target a specific element like `.retail-banking-page`
    const opt = {
      margin: [0.5, 0.5, 0.5, 0.5], // Adjusted margins for a better fit
      filename: "Retail_Banking_Detail.pdf",
      image: { type: "jpeg", quality: 0.98 }, // High-quality image
      html2canvas: { scale: 0.75 }, // Lower scale to reduce the image size in the PDF
      jsPDF: { unit: "in", format: "letter", orientation: "portrait" },
    };
    html2pdf().from(element).set(opt).save();
  };

  return (
    <div className="retail-banking-page">
      <div className="header">
        <Link to="/" className="home-link">
          <span role="img" aria-label="Home" className="home-icon">
            🏠
          </span>
        </Link>

        <h1 className="title">Automobile</h1>

        <button className="export-button" onClick={handleExportPDF}>
          Export to PDF
        </button>
      </div>

      {/* Render sections, categories, and topics from the JSON */}
      {sections.map((section, sectionIdx) => (
        <div key={sectionIdx} className="section">
          <h2>{section.name}</h2>
          <div className="categories">
            {section.categories.map((category, categoryIdx) => (
              <div key={categoryIdx} className="category">
                <h3>{category.name}</h3>
                <div className="topics">
                  {category.topics.map((topic, topicIdx) => (
                    <button
                      key={topicIdx}
                      className="topic-button"
                      onClick={() =>
                        handleTopicClick(section.name, category.name, topic)
                      }
                    >
                      {topic.name}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* Modal for displaying details */}
      {isModalOpen && (
        <Modal
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          content={modalContent}
        />
      )}
    </div>
  );
};

export default RetailBankingDetail;
